window.onload = function() {
    document.getElementById('section-video').className = 'onload-class';
    document.getElementById('preloader').className = 'display-none';
};