window.onload = function() {
    document.getElementById('intro-slider-wrapper').className = 'onload-class';
    document.getElementById('preloader').className = 'display-none';
};
