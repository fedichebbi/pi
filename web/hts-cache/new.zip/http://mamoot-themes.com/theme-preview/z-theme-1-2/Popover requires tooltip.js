<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="http://mamoot-themes.com/xmlrpc.php">

<title>Nothing found for  Theme Preview Z Theme 1 2 Popover%20Requires%20Tooltip Js</title>

<!-- All in One SEO Pack 2.3.12.1 by Michael Torbert of Semper Fi Web Design[252,295] -->
<link rel="author" href="https://plus.google.com/105127883858351183125/" />
<meta name="robots" content="noindex,follow" />

			<script>
			(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

			ga('create', 'UA-60746024-1', 'auto');
			
			ga('send', 'pageview');
			</script>
<!-- /all in one seo pack -->
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//maxcdn.bootstrapcdn.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Mamoot Themes &raquo; Feed" href="http://mamoot-themes.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Mamoot Themes &raquo; Comments Feed" href="http://mamoot-themes.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/mamoot-themes.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.7.9"}};
			!function(a,b,c){function d(a){var b,c,d,e,f=String.fromCharCode;if(!k||!k.fillText)return!1;switch(k.clearRect(0,0,j.width,j.height),k.textBaseline="top",k.font="600 32px Arial",a){case"flag":return k.fillText(f(55356,56826,55356,56819),0,0),!(j.toDataURL().length<3e3)&&(k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57331,65039,8205,55356,57096),0,0),b=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57331,55356,57096),0,0),c=j.toDataURL(),b!==c);case"emoji4":return k.fillText(f(55357,56425,55356,57341,8205,55357,56507),0,0),d=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55357,56425,55356,57341,55357,56507),0,0),e=j.toDataURL(),d!==e}return!1}function e(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i,j=b.createElement("canvas"),k=j.getContext&&j.getContext("2d");for(i=Array("flag","emoji4"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='contact-form-7-css'  href='http://mamoot-themes.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=4.7' type='text/css' media='all' />
<link rel='stylesheet' id='mamootthemes-style-css'  href='http://mamoot-themes.com/wp-content/themes/mamootthemes/style.css?ver=4.7.9' type='text/css' media='all' />
<link rel='stylesheet' id='mamootthemes-google-fonts-css'  href='http://fonts.googleapis.com/css?family=Roboto%3A400%2C100%2C300%2C500%2C700%2C900&#038;ver=4.7.9' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css?ver=4.7.9' type='text/css' media='all' />
<link rel='stylesheet' id='mamootthemes-layout-style-css'  href='http://mamoot-themes.com/wp-content/themes/mamootthemes/layouts/responsive.css?ver=4.7.9' type='text/css' media='all' />
<link rel='stylesheet' id='scroll-triggered-boxes-css'  href='http://mamoot-themes.com/wp-content/plugins/scroll-triggered-boxes/assets/css/styles.min.css?ver=1.4.3' type='text/css' media='all' />
<script type='text/javascript' src='http://mamoot-themes.com/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='http://mamoot-themes.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<link rel='https://api.w.org/' href='http://mamoot-themes.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://mamoot-themes.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://mamoot-themes.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.7.9" />
<style type="text/css">.mc4wp-form input[name="_mc4wp_required_but_not_really"] { position: absolute; top: -1000000px; }</style></head>

<body class="error404">
<div id="page" class="hfeed site">
	<a class="skip-link screen-reader-text" href="#content">Skip to content</a>

	<div class="section-navbar">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">

					<header id="masthead" class="site-header" role="banner">
						<a class="site-title-logo" href="http://mamoot-themes.com/" rel="home">
							<img src="http://mamoot-themes.com/wp-content/themes/mamootthemes/assets/img/logo.png">
						</a>
						<nav id="site-navigation" class="main-navigation" role="navigation">
							<button class="menu-toggle" aria-controls="menu" aria-expanded="false"><i class="fa fa-navicon"></i></button>
							<div class="menu-menu-1-container"><ul id="menu-menu-1" class="menu"><li id="menu-item-15" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-15"><a href="#themes">Themes</a></li>
<li id="menu-item-16" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-16"><a href="#subscribe">Subscribe</a></li>
<li id="menu-item-21" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-21"><a href="http://mamoot-themes.com/contact/">Contact</a></li>
</ul></div>						</nav><!-- #site-navigation -->
					</header><!-- #masthead -->

				</div>
			</div>
		</div>
	</div>

	<div id="content" class="site-content">

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

			<section class="error-404 not-found">
				<header class="page-header">
					<h1 class="page-title">Oops! That page can&rsquo;t be found.</h1>
				</header><!-- .page-header -->

				<div class="page-content">
					<p>It looks like nothing was found at this location. Maybe try one of the links below or a search?</p>

					<form role="search" method="get" class="search-form" action="http://mamoot-themes.com/">
				<label>
					<span class="screen-reader-text">Search for:</span>
					<input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" />
				</label>
				<input type="submit" class="search-submit" value="Search" />
			</form>
					
					
					<div class="widget widget_archive"><h2 class="widgettitle">Archives</h2><p>Try looking in the monthly archives. 🙂</p>		<label class="screen-reader-text" for="archives-dropdown--1">Archives</label>
		<select id="archives-dropdown--1" name="archive-dropdown" onchange='document.location.href=this.options[this.selectedIndex].value;'>
			
			<option value="">Select Month</option>
			
		</select>
		</div>
					
				</div><!-- .page-content -->
			</section><!-- .error-404 -->

		</main><!-- #main -->
	</div><!-- #primary -->


	</div><!-- #content -->

	<!--
	<div class="section-footer text-center">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">

					<footer id="colophon" class="site-footer" role="contentinfo">
						<div class="site-info">
							<a href="http://wordpress.org/">Proudly powered by WordPress</a>
							<span class="sep"> | </span>
							Theme: mamootthemes by <a href="http://underscores.me/" rel="designer">Underscores.me</a>.						</div>
					</footer>

				</div>
			</div>
		</div>
	</div>
	-->


  <div class="section-footer">
    <div class="container">
      <div class="row">
        <div class="col-sm-6 col-sm-offset-3 text-center">
          <img class="footer-logo" src="http://mamoot-themes.com/wp-content/themes/mamootthemes/assets/img/logo.png"></img>
          <ul class="list-inline">
            <li><a href="#themes">Themes</a></li>
            <li><a href="#subscribe">Subscribe</a></li>
            <li><a href="http://mamoot-themes.com/contact">Contact</a></li>
          </ul>
          <ul class="list-inline">
            <li><a href="http://facebook.com/mamootthemes"><i class="fa fa-facebook"></i></a></li>
            <li><a href="http://twitter.com/mamootthemes"><i class="fa fa-twitter"></i></a></li>
          </ul>
          <h3 class="footer-copyright">2015 &copy; Mamoot Themes. All Rights Reserved.</h3>
        </div>
      </div>
    </div>
  </div>




</div><!-- #page -->

<!-- Scroll Triggered Boxes v1.4.3 - https://wordpress.org/plugins/scroll-triggered-boxes/-->			<style type="text/css">
				#stb-23 {
					background: #19b5fe;
					color: #ffffff;										max-width: auto;
				}

							</style>
			<div class="stb-container stb-bottom-center-container">
				<div class="scroll-triggered-box stb stb-bottom-center" id="stb-23" style="display: none;"  data-box-id="23" data-trigger="percentage"
				 data-trigger-percentage="65" data-trigger-element=""
				 data-animation="slide" data-cookie="0" data-test-mode="0"
				 data-auto-hide="1">
					<div class="stb-content"><p>Make your website today with our new powerful theme. Z-Theme &#8211; Available now on <a href="http://goo.gl/NTE6qJ">Bootstrapbay</a></p>
</div>
					<span class="stb-close">&times;</span>
				</div>
			</div>
			<!-- / Scroll Triggered Box --><script type='text/javascript' src='http://mamoot-themes.com/wp-content/plugins/contact-form-7/includes/js/jquery.form.min.js?ver=3.51.0-2014.06.20'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpcf7 = {"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}}};
/* ]]> */
</script>
<script type='text/javascript' src='http://mamoot-themes.com/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=4.7'></script>
<script type='text/javascript' src='http://mamoot-themes.com/wp-content/themes/mamootthemes/js/navigation.js?ver=20120206'></script>
<script type='text/javascript' src='http://mamoot-themes.com/wp-content/themes/mamootthemes/js/main.js?ver=20140328'></script>
<script type='text/javascript' src='http://mamoot-themes.com/wp-content/themes/mamootthemes/js/skip-link-focus-fix.js?ver=20130115'></script>
<script type='text/javascript' src='http://mamoot-themes.com/wp-content/plugins/scroll-triggered-boxes/assets/js/script.min.js?ver=1.4.3'></script>
<script type='text/javascript' src='http://mamoot-themes.com/wp-includes/js/wp-embed.min.js?ver=4.7.9'></script>

</body>
</html>
