$(document).ready(function() {
    //BACKSTRETCH //
    $("body").backstretch([
        "assets/images/bg/blur-1.jpg",
        "assets/images/bg/blur-2.jpg",
        "assets/images/bg/blur-3.jpg",
        "assets/images/bg/blur-4.jpg"
    ], {
        duration: 4500,
        fade: 850
    });
});
